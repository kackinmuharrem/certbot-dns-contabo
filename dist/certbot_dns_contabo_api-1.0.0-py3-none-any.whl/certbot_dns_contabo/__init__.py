"""Contabo DNS Authenticator for Certbot"""

__version__ = "1.0.0"
